import random
import statistics
import pytest
from collections import Counter
from helpers import ApiClient

MIN_IMAGE_POOL = 20  # assumes TEST_IMAGE_DIR has at least this many images for meaningful invariants

@pytest.mark.order(10)
def test_no_identical_sides_and_no_exact_pair_repeats(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    seen_pairs = set()
    repeats = 0
    N = 80
    for _ in range(N):
        p = api.get_pair()
        L, R = p["left_sha256"], p["right_sha256"]
        assert L != R, "Engine served the same image on both sides."
        key = tuple(sorted([L, R]))
        repeats += 1 if key in seen_pairs else 0
        seen_pairs.add(key)
        # advance with arbitrary choice
        api.post_choice(p["round"], L, R, random.choice(["LEFT","RIGHT"]))

    # With a non-trivial pool, we should not see many repeats
    assert repeats <= N * 0.05, f"Too many exact-pair repeats: {repeats}/{N}"

@pytest.mark.order(11)
def test_recent_suppression_on_consecutive_rounds(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    last_images = set()
    consecutive_hits = 0
    N = 120
    for _ in range(N):
        p = api.get_pair()
        curr = {p["left_sha256"], p["right_sha256"]}
        # count if either side immediately repeats from last round
        if curr & last_images:
            consecutive_hits += 1
        last_images = curr
        api.post_choice(p["round"], *[p["left_sha256"], p["right_sha256"]], outcome="LEFT")

    # Allow a small number in tight pools, but it should be rare.
    assert consecutive_hits <= N * 0.15, f"Too many consecutive-round repeats: {consecutive_hits}/{N}"

@pytest.mark.order(12)
def test_mu_distance_trends_smaller_over_time(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    diffs_early = []
    diffs_late = []

    # collect early 40 diffs without posting outcomes (we still need to advance rounds)
    for _ in range(40):
        p = api.get_pair()
        ml = p["meta"]["left"]["mu"]
        mr = p["meta"]["right"]["mu"]
        diffs_early.append(abs(ml - mr))
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))

    # then 80 more rounds; collect last 40 as "late"
    buf = []
    for _ in range(80):
        p = api.get_pair()
        ml = p["meta"]["left"]["mu"]
        mr = p["meta"]["right"]["mu"]
        d = abs(ml - mr)
        buf.append(d)
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))
    diffs_late = buf[-40:]

    if len(diffs_early) >= 10 and len(diffs_late) >= 10:
        m_early = statistics.median(diffs_early)
        m_late  = statistics.median(diffs_late)
        # We expect the median mu-gap to shrink as the engine learns and targets close matches.
        assert m_late <= m_early * 1.10, f"Median mu-gap did not shrink (early={m_early:.2f}, late={m_late:.2f})."
