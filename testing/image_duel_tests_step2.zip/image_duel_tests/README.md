# Image Duel Engine — Test Suite (Step 1)

This is a black-box **pytest** suite that targets the HTTP API described in your YAML spec.
It focuses on **smoke**, **ratings (Elo+σ)**, and **skip resurfacing** basics.

## How to run

```bash
python -m venv .venv && source .venv/bin/activate
pip install pytest requests python-dotenv
export BASE_URL="http://localhost:6500/api"   # <- adjust to your backend
pytest -q
```

Alternatively, create a `.env` file from `.env.sample`.

## Modes

- **API Mode (default):** Tests call your running server using `BASE_URL`.
- **Import Mode (optional):** If you expose a Python module `engine_api` with
  `get_pair()` and `post_choice()` functions, the tests will auto-detect it and
  run a faster direct-call path. See `tests/helpers.py` for the expected shape.

## What Step 1 covers

- Bootstrapping the active directory and discovering images
- Smoke loop: GET /pair -> POST /choice -> repeat
- Elo expectation math and K-factor behavior against a small reference
- σ decay and exposure counters
- Skip action creates a cooldown window in [11, 49] rounds

**Next (Step 2):** pairing invariants, recent suppression, stability/stop-rule, gallery APIs.
