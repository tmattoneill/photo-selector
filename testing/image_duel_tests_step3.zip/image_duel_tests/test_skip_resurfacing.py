import random
import pytest
from helpers import ApiClient

@pytest.mark.order(3)
def test_skip_sets_cooldown_and_resurfaces(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Get a pair and SKIP it
    p = api.get_pair()
    left = p["left_sha256"]; right = p["right_sha256"]
    api.post_choice(p["round"], left, right, "SKIP")

    # Over next ~80 rounds, ensure at least one of these skipped items resurfaces.
    # (Engine injects skipped_eligible ~30% of rounds after cooldown 11..49)
    seen_again = False
    for _ in range(80):
        q = api.get_pair()
        if q["left_sha256"] in (left, right) or q["right_sha256"] in (left, right):
            seen_again = True
            break
        # choose arbitrary to advance
        outcome = random.choice(["LEFT","RIGHT"])
        api.post_choice(q["round"], q["left_sha256"], q["right_sha256"], outcome)

    assert seen_again, "A skipped image did not resurface within 80 rounds; check cooldown/injection logic."
