import time
import pytest
import random
from helpers import ApiClient

@pytest.mark.order(50)
def test_pair_selection_and_choice_perf(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    N = 50
    pair_times = []
    choice_times = []
    for _ in range(N):
        t0 = time.time()
        p = api.get_pair()
        pair_times.append(time.time() - t0)

        t0 = time.time()
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))
        choice_times.append(time.time() - t0)

    p95_pair   = sorted(pair_times)[int(0.95*N)-1]
    p95_choice = sorted(choice_times)[int(0.95*N)-1]

    # Soft performance expectations; adjust as needed for your environment
    assert p95_pair   < 0.2, f"/pair p95 too slow: {p95_pair:.3f}s"
    assert p95_choice < 0.2, f"/choice p95 too slow: {p95_choice:.3f}s"
