import os
import pytest
import random
from helpers import ApiClient

@pytest.mark.order(1)
def test_directory_scan_and_smoke_loop(base_url, test_image_dir):
    api = ApiClient(base_url)

    # 1) Set directory and expect >= some discovered files
    resp = api.set_directory(test_image_dir)
    assert "discovered" in resp and resp["discovered"] >= 1

    # 2) Get a pair and ensure basic shape
    seen_pairs = set()
    for _ in range(5):
        pair = api.get_pair()
        assert "round" in pair and "left_sha256" in pair and "right_sha256" in pair
        left, right = pair["left_sha256"], pair["right_sha256"]
        assert left != right, "Engine served identical images on both sides."
        seen_pairs.add(tuple(sorted([left, right])))

        # 3) Randomly decide or skip
        outcome = random.choice(["LEFT","RIGHT","SKIP"])
        api.post_choice(pair["round"], left, right, outcome)

    # 4) Grab app state to ensure it responds
    state = api.get_state()
    assert "round" in state
    assert "unseen_count" in state and "seen_count" in state
