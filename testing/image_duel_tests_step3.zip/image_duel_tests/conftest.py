import os
import pytest
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.getcwd(), ".env"), override=True)

@pytest.fixture(scope="session")
def base_url():
    url = os.environ.get("BASE_URL")
    if not url:
        pytest.skip("BASE_URL not set. Set it or create a .env. See .env.sample.")
    return url.rstrip("/")

@pytest.fixture(scope="session")
def test_image_dir():
    d = os.environ.get("TEST_IMAGE_DIR")
    if not d:
        pytest.skip("TEST_IMAGE_DIR not set. Set to a directory with images.")
    return d
