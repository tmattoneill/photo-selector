import os
import time
import random
from typing import Tuple, Set, List
import pytest
import requests

from helpers import ApiClient

def _mk_gallery(api: ApiClient, policy_body) -> Tuple[int, int]:
    base = os.environ["BASE_URL"].rstrip("/")
    res = requests.post(f"{base}/galleries", json=policy_body, timeout=30); res.raise_for_status()
    created = res.json()
    return created["gallery_id"], created["size"]

def _get_gallery_sha_set(gid: int) -> Set[str]:
    base = os.environ["BASE_URL"].rstrip("/")
    res = requests.get(f"{base}/galleries/{gid}", timeout=30); res.raise_for_status()
    det = res.json()
    return {img["sha256"] for img in det.get("images", [])}

def _delete_gallery(gid: int):
    base = os.environ["BASE_URL"].rstrip("/")
    try:
        requests.delete(f"{base}/galleries/{gid}", timeout=30)
    except Exception:
        pass

def _warm_rounds(api: ApiClient, n: int):
    for _ in range(n):
        p = api.get_pair()
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))

def _choose_threshold_for_target_size(api: ApiClient, target_min=12, target_max=48) -> Tuple[dict, int]:
    """Try a few ci thresholds to land a gallery size between target_min and target_max."""
    trials = [1600, 1550, 1525, 1500, 1475, 1450]
    for thr in trials:
        body = {
            "name": f"pytest-ci-{thr}-{int(time.time())}",
            "selection_policy": "threshold_ci",
            "selection_params": {"z": 1.0, "min_ci_lower": thr},
            "duplicates_policy": "collapse_to_canonical"
        }
        try:
            gid, size = _mk_gallery(api, body)
            _delete_gallery(gid)  # cleanup; we only probe size
            if target_min <= size <= target_max:
                return (body, size)
        except Exception:
            continue
    # Fallback: last tried threshold
    return (body, size if 'size' in locals() else 0)

@pytest.mark.order(40)
def test_stability_trend_and_ready_flag(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Warm the engine
    _warm_rounds(api, 120)

    # Pick a threshold that yields ~20-40 items
    body, size0 = _choose_threshold_for_target_size(api, 12, 48)
    # Create snapshot A
    bodyA = dict(body); bodyA["name"] = f"pytest-snap-A-{int(time.time())}"
    gidA, sizeA = _mk_gallery(api, bodyA)
    setA = _get_gallery_sha_set(gidA)

    # Advance more rounds
    _warm_rounds(api, 200)

    # Snapshot B
    bodyB = dict(body); bodyB["name"] = f"pytest-snap-B-{int(time.time())}"
    gidB, sizeB = _mk_gallery(api, bodyB)
    setB = _get_gallery_sha_set(gidB)

    # Compare membership drift (symmetric difference ratio)
    if sizeA > 0 and sizeB > 0:
        symdiff = (setA ^ setB)
        denom = max(len(setA | setB), 1)
        drift_ratio = len(symdiff) / denom
        # Expect drift to be modest after 320 rounds total
        assert drift_ratio <= 0.35, f"""Top-set membership drift too high: {drift_ratio:.2%}.
        A={len(setA)}, B={len(setB)}, Δ={len(symdiff)}"""

    # Check ready flag eventually flips to True (best-effort; don't fail the suite if not)
    state = api.get_state()
    if "ready_to_finish" in state:
        # After ~320 rounds on typical pools, this should tend to true
        assert isinstance(state["ready_to_finish"], bool)
        # soft expectation: not a hard assert
    _delete_gallery(gidA); _delete_gallery(gidB)

@pytest.mark.order(41)
def test_recent_pair_window_enforcement(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Attempt to force an exact pair within 40 rounds; expect very low chance of repeat
    target_pair = None
    repeats = 0
    for i in range(60):
        p = api.get_pair()
        key = tuple(sorted([p["left_sha256"], p["right_sha256"]]))
        if target_pair is None:
            target_pair = key
        else:
            if key == target_pair:
                repeats += 1
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"])) 

    assert repeats == 0, f"Engine repeated the same exact pair within 60 rounds ({repeats} repeats)."

@pytest.mark.order(49)
@pytest.mark.skipif(os.environ.get("TEST_PERF") != "1", reason="Set TEST_PERF=1 to enable perf sanity test.")
def test_perf_pair_and_choice_p95(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    import statistics
    lat_pairs = []
    lat_choices = []
    N = 120

    for _ in range(N):
        t0 = time.time()
        p = api.get_pair()
        lat_pairs.append((time.time() - t0) * 1000.0)
        t1 = time.time()
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"])) 
        lat_choices.append((time.time() - t1) * 1000.0)

    p95_pairs = statistics.quantiles(lat_pairs, n=20)[-1]
    p95_choices = statistics.quantiles(lat_choices, n=20)[-1]
    # Generous thresholds to avoid flakiness in CI/network; tune as needed.
    assert p95_pairs <= 500, f"/pair p95 too slow: {p95_pairs:.1f} ms"
    assert p95_choices <= 500, f"/choice p95 too slow: {p95_choices:.1f} ms"
