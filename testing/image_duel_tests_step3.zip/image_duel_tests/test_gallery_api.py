import random
import pytest
from helpers import ApiClient

@pytest.mark.order(30)
def test_gallery_lifecycle_topk_then_patch_and_delete(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Warm up engine a bit so rankings exist
    for _ in range(40):
        p = api.get_pair()
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))

    # Create gallery via threshold_ci policy (robust even if target_top_k is null)
    body = {
        "name": "pytest-ci-threshold",
        "selection_policy": "threshold_ci",
        "selection_params": {"z": 1.0, "min_ci_lower": 1400},
        "duplicates_policy": "collapse_to_canonical"
    }
    # POST
    r = api.post_choice  # silence linter about unused import; real call below
    import requests, os
    base = os.environ["BASE_URL"].rstrip("/")
    res = requests.post(f"{base}/galleries", json=body, timeout=30); res.raise_for_status()
    created = res.json()
    gid = created["gallery_id"]
    assert created["size"] >= 0
    assert created["name"] == "pytest-ci-threshold"

    # GET list
    res = requests.get(f"{base}/galleries", timeout=30); res.raise_for_status()
    lst = res.json()
    assert any(g["gallery_id"] == gid for g in lst)

    # GET details
    res = requests.get(f"{base}/galleries/{gid}", timeout=30); res.raise_for_status()
    det = res.json()
    assert det["gallery_id"] == gid
    assert "images" in det and isinstance(det["images"], list)

    # PATCH rename
    res = requests.patch(f"{base}/galleries/{gid}", json={"name": "pytest-renamed", "re_rank": True}, timeout=30); res.raise_for_status()
    # DELETE
    res = requests.delete(f"{base}/galleries/{gid}", timeout=30); res.raise_for_status()

@pytest.mark.order(31)
def test_gallery_manual_selection_roundtrip(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    sha_pool = set()
    for _ in range(30):
        p = api.get_pair()
        sha_pool.add(p["left_sha256"]); sha_pool.add(p["right_sha256"])
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))
        if len(sha_pool) >= 12:
            break

    manual_list = list(sha_pool)[:12]

    import requests, os
    base = os.environ["BASE_URL"].rstrip("/")
    body = {
        "name": "pytest-manual",
        "selection_policy": "manual",
        "selection_params": {"sha256_list": manual_list},
        "duplicates_policy": "include_duplicates"
    }
    res = requests.post(f"{base}/galleries", json=body, timeout=30); res.raise_for_status()
    created = res.json()
    gid = created["gallery_id"]

    res = requests.get(f"{base}/galleries/{gid}", timeout=30); res.raise_for_status()
    det = res.json()
    got = {img["sha256"] for img in det.get("images", [])}
    assert set(manual_list).issubset(got), "Manual gallery missing requested items."

    # Clean up
    requests.delete(f"{base}/galleries/{gid}", timeout=30)
