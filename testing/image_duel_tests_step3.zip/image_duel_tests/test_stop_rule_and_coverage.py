import random
import pytest
from helpers import ApiClient

@pytest.mark.order(20)
def test_coverage_monotonicity_and_ready_flag_shape(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Sample state before and after a burst of rounds
    s0 = api.get_state()
    seen0  = s0.get("seen_count", 0)
    unseen0 = s0.get("unseen_count", 0)

    R = 150
    for _ in range(R):
        p = api.get_pair()
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))

    s1 = api.get_state()
    seen1  = s1.get("seen_count", 0)
    unseen1 = s1.get("unseen_count", 0)

    assert unseen1 <= unseen0, "unseen_count should not increase over time."
    assert seen1 >= seen0, "seen_count should not decrease over time."
    assert isinstance(s1.get("round"), int), "/api/state missing 'round' int."
    assert isinstance(s1.get("unseen_count"), int), "/api/state missing 'unseen_count'."
    assert isinstance(s1.get("seen_count"), int), "/api/state missing 'seen_count'."
    # ready_to_finish is optional but if present must be boolean
    if "ready_to_finish" in s1:
        assert isinstance(s1["ready_to_finish"], bool)
