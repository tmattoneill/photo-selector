import math
import pytest
from helpers import ApiClient

def elo_expected(mu_a, mu_b):
    return 1.0 / (1.0 + 10 ** ((mu_b - mu_a)/400.0))

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

@pytest.mark.order(2)
def test_elo_update_direction_sigma_decay(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Pull two pairs, but reuse the same two if possible to get deterministic-ish updates.
    # First request: pick outcome based on which has lower mu to enforce a "surprise" upset.
    p1 = api.get_pair()
    left = p1["left_sha256"]; right = p1["right_sha256"]
    ml = p1["meta"]["left"]["mu"]; mr = p1["meta"]["right"]["mu"]
    sl = p1["meta"]["left"]["sigma"]; sr = p1["meta"]["right"]["sigma"]

    # Post outcome: choose the underdog to win to verify mu deltas go the right direction.
    underdog = "LEFT" if ml < mr else "RIGHT"
    api.post_choice(p1["round"], left, right, underdog)

    # Second request to ensure ratings changed
    p2 = api.get_pair()
    # Not necessarily the same pair, but we can at least assert that sigma decreases on exposure when we re-hit
    # If next pair isn't a repeat, this won't check the same images; so we fetch state preview if provided.
    # Optional: backend /state may include a topk_preview; if not, we skip sigma check.
    state = api.get_state()
    preview = state.get("topk_preview", [])
    # We can't guarantee presence of our exact images here; so this test focuses on directional expectations only.

    # Directional expectation: The winner's mu should have increased vs prior.
    # We need to re-fetch metadata for the same images; call another /pair until we see one of them or give up.
    seen = set()
    winner_sha = left if underdog == "LEFT" else right
    loser_sha = right if underdog == "LEFT" else left
    old = {
        winner_sha: {"mu": ml if winner_sha==left else mr, "sigma": sl if winner_sha==left else sr},
        loser_sha:  {"mu": mr if loser_sha==right else ml, "sigma": sr if loser_sha==right else sl},
    }

    # Try to encounter at least the winner again within a small budget
    found = False
    for _ in range(20):
        p = api.get_pair()
        if p["left_sha256"] == winner_sha:
            new_mu = p["meta"]["left"]["mu"]
            new_sigma = p["meta"]["left"]["sigma"]
            assert new_mu > old[winner_sha]["mu"] - 1e-6, "Winner's mu did not increase."
            assert new_sigma <= old[winner_sha]["sigma"] + 1e-6, "Winner's sigma did not decay."
            found = True
            break
        if p["right_sha256"] == winner_sha:
            new_mu = p["meta"]["right"]["mu"]
            new_sigma = p["meta"]["right"]["sigma"]
            assert new_mu > old[winner_sha]["mu"] - 1e-6, "Winner's mu did not increase."
            assert new_sigma <= old[winner_sha]["sigma"] + 1e-6, "Winner's sigma did not decay."
            found = True
            break
        # random choice to keep the loop going
        outcome = "LEFT"
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], outcome)

    if not found:
        pytest.skip("Could not re-encounter winner within 20 pairs; skip sigma assertion.")
