import importlib
import os
import random
import time
from typing import Optional, Dict, Any

import requests

class ApiClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    def set_directory(self, root: str) -> Dict[str, Any]:
        r = requests.post(f"{self.base_url}/directory", json={"root": root}, timeout=30)
        r.raise_for_status()
        return r.json()

    def get_pair(self) -> Dict[str, Any]:
        r = requests.get(f"{self.base_url}/pair", timeout=30)
        r.raise_for_status()
        return r.json()

    def post_choice(self, round_no: int, left: str, right: str, outcome: str) -> Dict[str, Any]:
        payload = {
            "round": round_no,
            "left_sha256": left,
            "right_sha256": right,
            "outcome": outcome
        }
        r = requests.post(f"{self.base_url}/choice", json=payload, timeout=30)
        r.raise_for_status()
        return r.json()

    def get_state(self) -> Dict[str, Any]:
        r = requests.get(f"{self.base_url}/state", timeout=30)
        r.raise_for_status()
        return r.json()

def try_import_engine_api():
    try:
        return importlib.import_module("engine_api")
    except Exception:
        return None

def choose_outcome_by_true_skill(meta_left, meta_right):
    # Heuristic: prefer the higher mu; if close, randomize
    dl = meta_left["mu"] - meta_right["mu"]
    if abs(dl) < 10:
        return random.choice(["LEFT","RIGHT"])
    return "LEFT" if dl > 0 else "RIGHT"
