import pytest
import random
from helpers import ApiClient

@pytest.mark.order(41)
def test_recent_window_suppression_strictness(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # We'll request 200 pairs and track rolling recent window
    window_size = 16
    recent = []
    duplicates = 0

    for _ in range(200):
        p = api.get_pair()
        pair = {p["left_sha256"], p["right_sha256"]}
        if any(x in recent for x in pair):
            duplicates += 1
        # update window
        recent.extend(list(pair))
        recent = recent[-window_size:]
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], outcome="LEFT")

    # In a well-sized dataset, duplicates from immediate reuse should be low
    assert duplicates <= 200 * 0.2, f"Too many recent-window violations: {duplicates}/200"
