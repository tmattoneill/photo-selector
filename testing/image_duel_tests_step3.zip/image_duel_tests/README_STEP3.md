# Step 3 — Stability, Stop-Rule Strictness, and Perf Sanity (Optional)

**What’s added**
- Stability trend via gallery snapshot membership drift (using `threshold_ci` policy)
- Recent-pair window enforcement (no exact pair re-serve within a short horizon)
- Optional perf sanity (enable with `TEST_PERF=1`)

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install pytest requests python-dotenv
export BASE_URL="http://localhost:6500/api"
export TEST_IMAGE_DIR="/absolute/path/to/images"
# Optional perf check:
export TEST_PERF=1
pytest -q
```

## Notes
- The stability test self-tunes a CI threshold to land a set size between 12 and 48,
  then compares two snapshots separated by ~200 rounds. We expect <=35% drift.
- The recent-pair test expects **zero** exact-pair repeats within 60 rounds.
- Perf thresholds are intentionally generous (p95 <= 500 ms) to avoid flakiness.
