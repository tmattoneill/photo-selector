import random
import pytest
from helpers import ApiClient

@pytest.mark.order(40)
def test_boundary_gap_and_stability_fields_present(base_url, test_image_dir):
    api = ApiClient(base_url)
    api.set_directory(test_image_dir)

    # Advance enough rounds to populate rankings
    for _ in range(200):
        p = api.get_pair()
        api.post_choice(p["round"], p["left_sha256"], p["right_sha256"], random.choice(["LEFT","RIGHT","SKIP"]))

    state = api.get_state()
    # The state should expose ready_to_finish boolean (if implemented)
    if "ready_to_finish" in state:
        assert isinstance(state["ready_to_finish"], bool)

    # Check optional telemetry fields (not required, but if present must be typed correctly)
    if "topk_preview" in state:
        assert isinstance(state["topk_preview"], list)
        for item in state["topk_preview"][:5]:
            assert "sha256" in item and isinstance(item["mu"], (int,float))
    # These may or may not be exposed; if present, assert sanity
    for fld in ["boundary_gap", "unseen_count", "seen_count"]:
        if fld in state:
            assert isinstance(state[fld], (int,float))
