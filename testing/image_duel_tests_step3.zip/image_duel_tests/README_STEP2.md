# Step 2 — Pairing Invariants, Stop-Rule, and Gallery API Tests

Adds tests for:
- Pairing invariants (no identical sides, minimal exact-pair repeats)
- Recent suppression (limit consecutive reuse)
- mu-gap trend (pairs converge to informative match-ups)
- Coverage monotonicity & state shape
- Gallery lifecycle (create/list/get/patch/delete) with `threshold_ci`
- Manual gallery selection roundtrip

## Install (adds nothing new vs Step 1)
```bash
python -m venv .venv && source .venv/bin/activate
pip install pytest requests python-dotenv
export BASE_URL="http://localhost:6500/api"
export TEST_IMAGE_DIR="/absolute/path/to/a/folder/with/images"
pytest -q
```

> Tip: If your dataset is very small (<20 images), a few invariants may be skipped
or become less strict. Increase TEST_IMAGE_DIR size to get stronger guarantees.
